# Module: default
# Author: Rayflix, noway
# Created on: 19.01.2022
import xbmcplugin
from urllib.parse import quote_plus, unquote_plus, parse_qsl
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile
import os
import shutil
import requests
import random
import re

artworkPath = xbmcvfs.translatePath('special://home/addons/plugin.program.skinrayflix/resources/media/')
fanart = artworkPath + "fanart.jpg"

def notice(content):
    log(content, xbmc.LOGINFO)

def log(msg, level=xbmc.LOGINFO):
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    xbmc.log('%s: %s' % (addonID, msg), level)

def showErrorNotification(message):
    xbmcgui.Dialog().notification("UptoRay", message,
                                  xbmcgui.NOTIFICATION_ERROR, 5000)
def showInfoNotification(message):
    xbmcgui.Dialog().notification("UptoRay", message, xbmcgui.NOTIFICATION_INFO, 15000)

def add_dir(name, mode, thumb):
    u = sys.argv[0] + "?" + "action=" + str(mode)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'icon': thumb})
    liz.setProperty("fanart_image", fanart)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def main_menu():
    xbmcplugin.setPluginCategory(__handle__, "Choix UptoRay")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("[COLOR red]METTRE A JOUR L'ADDON[/COLOR]", 'addon_maj', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]COMPTES PREMIUM ALEATOIRE CLIC ICI[/COLOR]", 'menuKey', artworkPath + 'icone.png')
    add_dir("Choix SKins [COLOR red]U2Pplay HK[/COLOR] Clic ici", 'hk', artworkPath + 'icone.png')
    add_dir("Choix SKins [COLOR green]vStream[/COLOR] Clic ici", 'vstream', artworkPath + 'icone.png')
    add_dir("[COLOR red]NETTOYER KODI[/COLOR]", 'nettoye', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)

def hk():
    xbmcplugin.setPluginCategory(__handle__, "Choix skin HK")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("[COLOR red]u2Play[/COLOR] SKIN LIGHT [COLOR deepskyblue](le + leger)[/COLOR]", 'choixskinlite', artworkPath + 'icone.png')
    add_dir("[COLOR red]u2Play[/COLOR] SKIN FULL [COLOR deepskyblue](le + gourmand)[/COLOR]", 'choixskinfull', artworkPath + 'icone.png')
    add_dir("[COLOR red]u2Play[/COLOR] SKIN KIDS [COLOR deepskyblue](special enfants)[/COLOR]", 'choixskinkids', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)

def vstream():
    xbmcplugin.setPluginCategory(__handle__, "Choix skin vStream")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("Ajouter les Codes Past pour [COLOR green]vStream[/COLOR] Clic ici", 'choixpastall', artworkPath + 'icone.png')
    add_dir("[COLOR green]vStream[/COLOR] SKIN LIGHT [COLOR deepskyblue](le + leger)[/COLOR]", 'choixskinlitev', artworkPath + 'icone.png')
    add_dir("[COLOR green]vStream[/COLOR] SKIN FULL [COLOR deepskyblue](le + gourmand)[/COLOR]", 'choixskinfullv', artworkPath + 'icone.png')
    add_dir("[COLOR green]vStream[/COLOR] SKIN KIDS [COLOR deepskyblue](special enfants)[/COLOR]", 'choixskinkidsv', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)

def nettoye():
    xbmcplugin.setPluginCategory(__handle__, "NETTOYER KODI")
    xbmcplugin.setContent(__handle__, 'files')
    add_dir("[COLOR red]NETTOYER TOUT D'UN COUP : [/COLOR]clic ici", 'vider_cache', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]Vider Cache uniquement[/COLOR]", 'cache_seul', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]Vider Thumbnails uniquement[/COLOR]", 'thumb_seul', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]Vider Tmp uniquement[/COLOR]", 'tmp_seul', artworkPath + 'icone.png')
    add_dir("[COLOR deepskyblue]Vider Packages uniquement[/COLOR]", 'package_seul', artworkPath + 'icone.png')
    xbmcplugin.endOfDirectory(handle=__handle__, succeeded=True)       
       
def menuKey():
    tabkey = extractAnotpad()
    nb = 0
    ok = False
    while tabkey:
        keyUpto = random.choice(tabkey)
        status, validite = testUptobox(keyUpto)
        if status == "Success":
            showInfoNotification("Notification(Key Upto ok! expire: %s)" %validite)
            ok = True
            break
        else:
            tabkey.remove(keyUpto)
            showErrorNotification("Prevenir Ray key: %s HS" %keyUpto)
            nb += 1
        if nb > 50:
            break
            return
    if ok:
        # config u2play
        try:
            addon = xbmcaddon.Addon("plugin.video.sendtokodiU2P")
            addon.setSetting(id="keyupto", value=keyUpto)
            nb_items = "50"
            addon.setSetting(id="nb_items", value=nb_items)
            thumbnails = "5000"
            addon.setSetting(id="thumbnails", value=thumbnails)
        except Exception as e:
            notice("Erreur HK: " + str(e))
        
        # config vstream
        try:
            addon = xbmcaddon.Addon("plugin.video.vstream")
            addon.setSetting(id="hoster_uptobox_token", value=keyUpto)
        except Exception as e:
            notice("Erreur Vstream: " + str(e))
        
        #config catchup
        try:
            addon = xbmcaddon.Addon("plugin.video.catchuptvandmore")
            mail = "rayflix@laposte.net"
            mot2passe = "Mot2passe"
            addon.setSetting(id="nrj.login", value=mail)
            addon.setSetting(id="6play.login", value=mail)
            addon.setSetting(id="rmcbfmplay.login", value=mail)
            addon.setSetting(id="nrj.password", value=mot2passe)
            addon.setSetting(id="6play.password", value=mot2passe)
            addon.setSetting(id="rmcbfmplay.password", value=mot2passe)
        except Exception as e:
            notice("Erreur CatchUp: " + str(e))

        showInfoNotification("Config Comptes ok")

def importSkin(zipurl):
    # telechargement et extraction du zip
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))
    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(COPIE SKIN OK,Faites retour et profitez !)")
    xbmc.sleep(2000)

     
def importpastall():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/past_all.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))
    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(ALL PAST OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def addon_maj():
    # telechargement et extraction du zip
    zipurl = 'https://github.com/rayflix76/pack/raw/kodi/addon_maj.zip'
    with urlopen(zipurl) as zipresp:
        with ZipFile(BytesIO(zipresp.read())) as zfile:
            zfile.extractall(xbmc.translatePath('special://home/temp/temp/'))
    # copie des fichiers extraie
    source_dir = xbmc.translatePath('special://home/temp/temp/addon_data')
    destination_dir = xbmc.translatePath('special://home/userdata/addon_data')
    source_dir2 = xbmc.translatePath('special://home/temp/temp/addons/skin.project.aura')
    destination_dir2 = xbmc.translatePath('special://home/addons/skin.project.aura')
    shutil.copytree(source_dir, destination_dir, dirs_exist_ok=True)
    shutil.copytree(source_dir2, destination_dir2, dirs_exist_ok=True)
    xbmc.executebuiltin("Notification(EXTRACTION OK,Mise à jour effectuée !)")
    xbmc.sleep(2000)

def vider_cache():
    xbmc.executebuiltin("Notification(FICHIER TEMP,Effacement en cours...)")
    # suppression dossier temporaire
    dirPath = xbmc.translatePath('special://home/temp/temp/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    xbmc.executebuiltin("Notification(DOSSIER PACKAGES,Effacement en cours...)")
    # suppression dossier packages
    dirPath = xbmc.translatePath('special://home/addons/packages/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    xbmc.executebuiltin("Notification(DOSSIER THUMBNAILS,Effacement en cours...)")
    # suppression dossier thumbnails
    dirPath = xbmc.translatePath('special://home/userdata/Thumbnails/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    xbmc.executebuiltin("Notification(CACHE TEMP,Effacement en cours...)")
    # suppression dossier cache
    dirPath = xbmc.translatePath('special://home/cache/temp/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(ATTENTION KODI VA SE FERMER , Relancez le...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    xbmc.sleep(2000)
    xbmc.executebuiltin('Quit')

def tmp_seul():
    xbmc.executebuiltin("Notification(FICHIER TEMP,Effacement en cours...)")
    # suppression dossier temporaire
    dirPath = xbmc.translatePath('special://home/temp/temp/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    xbmc.executebuiltin("Notification(TERMINE , ...)")
    # actualisation du skin
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    
def package_seul():
    xbmc.executebuiltin("Notification(DOSSIER PACKAGES,Effacement en cours...)")
    # suppression dossier packages
    dirPath = xbmc.translatePath('special://home/addons/packages/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(TERMINE , ...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')

def thumb_seul():
    xbmc.executebuiltin("Notification(DOSSIER THUMBNAILS,Effacement en cours...)")
    # suppression dossier thumbnails
    dirPath = xbmc.translatePath('special://home/userdata/Thumbnails/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(ATTENTION KODI VA SE FERMER , Relancez le...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')
    xbmc.sleep(2000)
    xbmc.executebuiltin('Quit')

def cache_seul():
    xbmc.executebuiltin("Notification(CACHE TEMP,Effacement en cours...)")
    # suppression dossier cache
    dirPath = xbmc.translatePath('special://home/cache/temp/')
    try:
       shutil.rmtree(dirPath)
    except:
       print('Error while deleting directory')
    xbmc.sleep(1000)
    # actualisation du skin
    xbmc.executebuiltin("Notification(TERMINE , ...)")
    xbmc.sleep(2000)
    xbmc.executebuiltin('ReloadSkin')

def extractAnotpad():
    numAnotepad = __addon__.getSetting("numAnotepad")
    motifAnotepad = r'.*<\s*div\s*class\s*=\s*"\s*plaintext\s*"\s*>(?P<txAnote>.+?)</div>.*'
    url = "https://anotepad.com/note/read/" + numAnotepad.strip()
    rec = requests.get(url)
    r = re.match(motifAnotepad, rec.text, re.MULTILINE|re.DOTALL)
    tabKey = [x.strip() for x in r.group("txAnote").splitlines() if x]
    return tabKey 

def testUptobox(key):
    url = 'https://uptobox.com/api/user/me?token=' + key
    headers = {'Accept': 'application/json'}
    try:
        data = requests.get(url, headers=headers).json()
        status = data["message"]
        validite = data["data"]["premium_expire"]
    except:
        status = "out"
        validite = ""
    return status, validite 

def router(paramstring):
    params = dict(parse_qsl(paramstring))    
    dictActions = {
        #key uptobox
        'menuKey':(menuKey, ""),
        #skin
        'choixpastall': (importpastall, ""),
        'choixskinlite': (importSkin, 'https://github.com/rayflix76/pack/raw/kodi/full_films.zip'),
        'choixskinfull': (importSkin, 'https://github.com/rayflix76/pack/raw/kodi/light_series.zip'),
        'choixskinkids': (importSkin, 'https://github.com/rayflix76/pack/raw/kodi/light_films.zip'),
        'choixskinlitev': (importSkin, 'https://github.com/rayflix76/pack/raw/kodi/light_light.zip'),
        'choixskinfullv': (importSkin, 'https://github.com/rayflix76/pack/raw/kodi/full_perso.zip'),
        'choixskinkidsv': (importSkin, 'https://github.com/rayflix76/pack/raw/kodi/light_kids.zip'),
        #skin hk
        'hk': (hk, ""),
        #skin vstream
        "vstream": (vstream, ""),
        'addon_maj': (addon_maj, ""),
        #nettoyage
        'vider_cache': (vider_cache, ""),
        'cache_seul': (cache_seul, ""),
        'tmp_seul': (tmp_seul, ""),
        'package_seul': (package_seul, ""),
        'thumb_seul': (thumb_seul, ""),
        'nettoye': (nettoye, ""),
        }
        

    if params:
        fn = params['action']
        if fn in dictActions.keys():
            argv = dictActions[fn][1]
            if argv:
                dictActions[fn][0](argv)
            else:
                dictActions[fn][0]()
        else:
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
         main_menu()

if __name__ == '__main__':
    __addon__ = xbmcaddon.Addon("plugin.program.skinrayflix")
    __handle__ = int(sys.argv[1])
    router(sys.argv[2][1:])